package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

/**
 * 
 * @author vennalla
 *
 */
public class PizzaOrderDAO implements IPizzaOrderDAO {
	
	Map<Integer,PizzaOrder> pizzaEntry = new HashMap<Integer,PizzaOrder>();
	Map<Integer,Customer> customerEntry = new HashMap<Integer, Customer>();

	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
	
		customerEntry.put(customer.getCustomerId(), customer);
		pizzaEntry.put(pizza.getOrderId(), pizza);
		return 0;
	}

	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		
		if(!pizzaEntry.containsKey(orderid))
		{	
			throw new PizzaException("Order not found");
		}
		PizzaOrder order = pizzaEntry.get(orderid);
		return order;
	}

}
