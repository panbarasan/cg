package com.cg.pizzaorder.ui;

import java.util.Date;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.repository.PizzaToppingDB;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;
import com.cg.pizzaorder.utils.PhoneValidator;

public class Client {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		IPizzaOrderService pizzaOrderService = new PizzaOrderService();
		String choice = null;
		do {
		System.out.println("1)Place Order\n2)Display Order\n3)Exit");
		int option = scanner.nextInt();
		
		switch(option) {
		case 1:{
			System.out.println(PizzaToppingDB.pizzaToppings);
			System.out.println("Enter name of the customer");
			String custName = scanner.next();
			System.out.println("Enter customer address");
			String address = scanner.next();
			System.out.println("Enter customer phone number");
			String phone = scanner.next();
			if(!(PhoneValidator.validatePhone(phone))) {
				try {
					throw new PizzaException("Please enter valid phone number");
				} catch (PizzaException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			System.out.println("Type of Pizza Topping preferred");
			String pizzaTopp = scanner.next();
			double price = 350;
			if(pizzaTopp.equalsIgnoreCase("Capsicum")) {
				price = price + 30;
			}
			else if(pizzaTopp.equalsIgnoreCase("Mushroom")) {
				price = price + 50;
			}
			else if(pizzaTopp.equalsIgnoreCase("Jalapeno")) {
				price = price + 70;
			}
			else if(pizzaTopp.equalsIgnoreCase("Panner")) {
				price = price + 85;
			}
			else {
				//System.out.println("Sorry this topping not available");
				try {
					throw new PizzaException("Please enter from above topping only");
				} catch (PizzaException e) {
					
					e.printStackTrace();
				}
				break;
			}
			int customerId = (int) (Math.random()*1000);
			int orderId = (int) (Math.random()*1000);
			Customer customer = new Customer(customerId,custName,address,phone);
			PizzaOrder pizza = new PizzaOrder(orderId,customerId,price);
			try {
				pizzaOrderService.placeOrder(customer, pizza);
			} catch (PizzaException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Your Pizza Order is placed along with Order ID "+orderId+"at "+new Date());
		}break;
		case 2:{
			System.out.println("Enter order id");
			int orderid = scanner.nextInt();
		//	System.out.println(pizzaOrderService.getOrderDetails(orderid));
			try {
				System.out.println(pizzaOrderService.getOrderDetails(orderid));
			} catch (PizzaException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}break;
		case 3:{
			System.exit(0);
		}break;
		default:{
			System.out.println("Please enter from above options only");
		}break;
		
		}
		System.out.println("press y to continue");
		choice = scanner.next();
		}while(choice.equalsIgnoreCase("y"));

		scanner.close();
	}

}
