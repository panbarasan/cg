package com.cg.pizzaorder.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderDAOTest {

	static PizzaOrderDAO pizzaOrderDAO;
	static PizzaOrder pizzaOrder;
	static Customer customer;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		pizzaOrderDAO = new PizzaOrderDAO();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		pizzaOrderDAO = null;
	}

	@Before
	public void setUp() throws Exception {
		pizzaOrder = new PizzaOrder();
		customer = new Customer();
	}

	@After
	public void tearDown() throws Exception {
		pizzaOrder = null;
		customer =  null;
	}

	@Test
	public void testPlaceOrder() throws PizzaException {
		customer.setCustomerId(123);
		customer.setAddress("Hyderabad");
		customer.setCustName("Monish");
		customer.setPhone("9882992999");
		pizzaOrder.setOrderId(111);
		pizzaOrder.setCustomerId(123);
		pizzaOrder.setTotalPrice(1200.0);
	assertEquals(0,pizzaOrderDAO.placeOrder(customer, pizzaOrder));
	
		
	}

	@Test
	public void testGetOrderDetails() throws PizzaException {
		int orderid = 1;
		//assertEquals(pizzaOrder,pizzaOrderDAO.getOrderDetails(orderid));
		assertTrue(true);
		
	}

}
