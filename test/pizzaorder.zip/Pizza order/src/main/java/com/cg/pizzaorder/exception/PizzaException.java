package com.cg.pizzaorder.exception;

public class PizzaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PizzaException() {
		
	}
	
	public PizzaException(String message) {
		super(message);
	}
	
	

}
