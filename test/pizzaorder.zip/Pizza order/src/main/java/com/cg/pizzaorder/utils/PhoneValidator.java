package com.cg.pizzaorder.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PhoneValidator {
	
static Pattern phoneptn = Pattern.compile("^[0-9]{10}$"); 
	
	public static boolean validatePhone(String Phone) {
		Matcher match = phoneptn.matcher(Phone);
		if(match.matches()) {
			return true;
		}
		else
			return false;
	}

}
