package com.cg.pizzaorder.repository;

import java.util.HashMap;
import java.util.Map;

public class PizzaToppingDB {
	
	public static Map<String,Integer> pizzaToppings = new HashMap<String, Integer>();

	static {
		
	  pizzaToppings.put("Capsicum", 30);
	  pizzaToppings.put("Mushroom", 50);
	  pizzaToppings.put("Jalapeno", 70);
	  pizzaToppings.put("Panner", 85);
		
	}
}
