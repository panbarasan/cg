package step;

import static org.junit.Assert.assertEquals;


import java.util.List;
import java.util.regex.Pattern;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.factory.BrowserFactory;
import com.cg.pages.PersonalDetailPage;
import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStep {
	WebDriver driver;
	PersonalDetailPage personalPage;

	@Before
	public void start() {
		driver = BrowserFactory.startBrowser("chrome",
				"D:\\Users\\panbag\\Desktop\\BDD wrkspace\\177510_panbarasan\\src\\test\\java\\html\\PersonalDetails.html");

	}

	@Given("^user is in personal detail page$")
	public void user_is_in_personal_detail_page() throws Throwable {

		personalPage = PageFactory.initElements(driver, PersonalDetailPage.class);
	}

	@Then("^verify the tittle personal detail if it is not match$")
	public void verify_the_tittle_personal_detail_if_it_is_not_match() throws Throwable {

		assertEquals("Personal Details", personalPage.getHeading());
		if (personalPage.getHeading().equals("Personal Details")) {
			System.out.println("tittle is matched");
		} else {
			System.out.println("tittle Not Matched");

		}

	}

	@Then("^stop the execution$")
	public void stop_the_execution() throws Throwable {
		driver.quit();
	}

	@When("^the user leaves first name empty$")
	public void the_user_leaves_first_name_empty() throws Throwable {
		personalPage.setF_name("");
		personalPage.setL_name("g");
		personalPage.setEmail("panbarasan176@gmail.com");
		personalPage.setContact_No("9789866479");
		personalPage.setAddressline_one("123 m.g.r street");
		personalPage.setAddressline_two("11 nehruu street");
		personalPage.setCity("chennai");
		personalPage.setState("Bangalore");

	}

	@Then("^alert message please fill the first name$")
	public void alert_message_please_fill_the_first_name() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String message = alt.getText();
			assertEquals("Please fill the First Name", message);
			if (message.contentEquals("Please fill the First Name")) {
				System.out.println("The text message on alert box is " + message);
			} else {
				System.out.println("the text message on alert is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			System.out.println("First name is Empty");
		}

	}

	@When("^the user leaves last name empty$")
	public void the_user_leaves_last_name_empty() throws Throwable {
		personalPage.setF_name("panbu");
		personalPage.setL_name("");
		personalPage.setEmail("panbarasan176@gmail.com");
		personalPage.setContact_No("9789866479");
		personalPage.setAddressline_one("123 m.g.r street");
		personalPage.setAddressline_two("11 nehruu street");
		personalPage.setCity("chennai");
		personalPage.setState("Bangalore");
	}

	@Then("^alert message please fill the last name$")
	public void alert_message_please_fill_the_last_name() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String message = alt.getText();
			assertEquals("Please fill the Last Name", message);
			if (message.contentEquals("Please fill the Last Name")) {
				System.out.println("The text message on alert box is " + message);
			} else {
				System.out.println("the text message on alert is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			System.out.println("Last name is Empty");
		}
	}

	@When("^the user leaves email empty$")
	public void the_user_leaves_email_empty() throws Throwable {
		personalPage.setF_name("panbu");
		personalPage.setL_name("g");
		personalPage.setEmail("");
		personalPage.setContact_No("9789866479");
		personalPage.setAddressline_one("123 m.g.r street");
		personalPage.setAddressline_two("11 nehruu street");
		personalPage.setCity("chennai");
		personalPage.setState("Bangalore");

	}

	@Then("^alert message please fill the email$")
	public void alert_message_please_fill_the_email() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String message = alt.getText();
			assertEquals("Please fill the Email", message);
			if (message.contentEquals("Please fill the Email")) {
				System.out.println("The text message on alert box is " + message);
			} else {
				System.out.println("the text message on alert is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			System.out.println("email is Empty");
		}
	}

	@When("^the user leaves mobile no empty$")
	public void the_user_leaves_mobile_no_empty() throws Throwable {
		personalPage.setF_name("panbu");
		personalPage.setL_name("g");
		personalPage.setEmail("panbarasan176@gmail.com");
		personalPage.setContact_No("");
		personalPage.setAddressline_one("123 m.g.r street");
		personalPage.setAddressline_two("11 nehruu street");
		personalPage.setCity("chennai");
		personalPage.setState("Bangalore");
	}

	@Then("^alert message please fill the contact no$")
	public void alert_message_please_fill_the_contact_no() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String message = alt.getText();
			assertEquals("Please fill the Mobile No.", message);
			if (message.contentEquals("Please fill the Mobile No.")) {
				System.out.println("The text message on alert box is " + message);
			} else {
				System.out.println("the text message on alert is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			System.out.println("mobile no is Empty");
		}
	}

	@When("^user enters incorrect mobileNo format and clicks the place order button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_place_order_button(DataTable mobile)
			throws Throwable {
		personalPage.setF_name("panbu");
		personalPage.setL_name("g");
		personalPage.setEmail("panbarasan176@gmail.com");
		personalPage.setContact_No("344567");
		personalPage.setAddressline_one("123 m.g.r street");
		personalPage.setAddressline_two("11 nehruu street");
		personalPage.setCity("chennai");
		personalPage.setState("Bangalore");

		List<String> objlist = mobile.asList(String.class);
		try {
			for (int i = 0; i < objlist.size(); i++) {
				personalPage.setContact_No(objlist.get(i));
				personalPage.Nxtbtnclick();
				Thread.sleep(1000);
				if (Pattern.matches("^[7-9]{1}[0-9]{9}$", objlist.get(i))) {
					System.out.println("**** valid phone no -Matched ");
				} else {
					System.out.println("Pattern not matching,Invalid mobile");
				}
			}
		} catch (Exception e) {
			System.out.println("invalid");
		}

	}

	@Then("^alert message please enter valid mobile no$")
	public void alert_message_please_enter_valid_mobile_no() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String message = alt.getText();
			assertEquals("Please enter valid Contact no.", message);
			if (message.contentEquals("Please enter valid Contact no.")) {
				System.out.println("The text message on alert box is " + message);
			} else {
				System.out.println("the text message on alert is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			System.out.println("mobile no is invalid");
		}

	}

	@When("^the user leaves address line (\\d+) empty$")
	public void the_user_leaves_address_line_empty(int arg1) throws Throwable {
		personalPage.setF_name("panbu");
		personalPage.setL_name("g");
		personalPage.setEmail("panbarasan176@gmail.com");
		personalPage.setContact_No("9789866479");
		personalPage.setAddressline_one("");
		personalPage.setAddressline_two("11 nehruu street");
		personalPage.setCity("chennai");
		personalPage.setState("Bangalore");
	}

	@When("^the user leaves address line one empty$")
	public void the_user_leaves_address_line_one_empty() throws Throwable {
		personalPage.setF_name("panbu");
		personalPage.setL_name("g");
		personalPage.setEmail("panbarasan176@gmail.com");
		personalPage.setContact_No("9789866479");
		personalPage.setAddressline_one("");
		personalPage.setAddressline_two("11 nehruu street");
		personalPage.setCity("chennai");
		personalPage.setState("Bangalore");
	}

	@Then("^alert message please fill the address lineone$")
	public void alert_message_please_fill_the_address_lineone() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String message = alt.getText();
			assertEquals("Please enter valid addresss line one.", message);
			if (message.contentEquals("Please enter valid  addresss line one.")) {
				System.out.println("The text message on alert box is " + message);
			} else {
				System.out.println("the text message on alert is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			System.out.println("address line one  is invalid");
		}

	}

	@When("^the user leaves address line two empty$")
	public void the_user_leaves_address_line_two_empty() throws Throwable {
		personalPage.setF_name("panbu");
		personalPage.setL_name("g");
		personalPage.setEmail("panbarasan176@gmail.com");
		personalPage.setContact_No("9789866479");
		personalPage.setAddressline_one("123 m.g.r street");
		personalPage.setAddressline_two("");
		personalPage.setCity("chennai");
		personalPage.setState("Bangalore");
	}

	@Then("^alert message please fill the address line two$")
	public void alert_message_please_fill_the_address_line_two() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String message = alt.getText();
			assertEquals("Please enter valid address line two.", message);
			if (message.contentEquals("Please enter valid address line two.")) {
				System.out.println("The text message on alert box is " + message);
			} else {
				System.out.println("the text message on alert is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			System.out.println("address line two no is invalid");
		}

	}

	@When("^the user leaves city empty$")
	public void the_user_leaves_city_empty() throws Throwable {
		personalPage.setF_name("panbu");
		personalPage.setL_name("g");
		personalPage.setEmail("panbarasan176@gmail.com");
		personalPage.setContact_No("9789866479");
		personalPage.setAddressline_one("123 m.g.r street");
		personalPage.setAddressline_two("112 arun street");
		personalPage.setCity("");
		personalPage.setState("Bangalore");

	}

	@Then("^alert message please fill the city$")
	public void alert_message_please_fill_the_city() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String message = alt.getText();
			assertEquals("Please select city", message);
			if (message.contentEquals("Please select city")) {
				System.out.println("The text message on alert box is " + message);
			} else {
				System.out.println("the text message on alert is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			System.out.println("city is empty");
		}

	}

	@When("^the user leaves state empty$")
	public void the_user_leaves_state_empty() throws Throwable {
		personalPage.setF_name("panbu");
		personalPage.setL_name("g");
		personalPage.setEmail("panbarasan176@gmail.com");
		personalPage.setContact_No("9789866479");
		personalPage.setAddressline_one("123 m.g.r street");
		personalPage.setAddressline_two("112 arun street");
		personalPage.setCity("chennai");
		personalPage.setState("");
	}

	@Then("^alert message please fill the state$")
	public void alert_message_please_fill_the_state() throws Throwable {
		try {
			Alert alt = driver.switchTo().alert();
			Thread.sleep(1000);
			String message = alt.getText();
			assertEquals("Please select state", message);
			if (message.contentEquals("Please select state")) {
				System.out.println("The text message on alert box is " + message);
			} else {
				System.out.println("the text message on alert is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			System.out.println("state is empty");
		}
	}

	@When("^the user entered valid details$")
	public void the_user_entered_valid_details() throws Throwable {
		personalPage.setF_name("panbu");
		personalPage.setL_name("g");
		personalPage.setEmail("panbarasan176@gmail.com");
		personalPage.setContact_No("9789866479");
		personalPage.setAddressline_one("123 m.g.r street");
		personalPage.setAddressline_two("112 arun street");
		personalPage.setCity("chennai");
		personalPage.setState("bangalore");

	}

	@Then("^navigate to Educationdetails$")
	public void navigate_to_Educationdetails() throws Throwable {
		System.out.println("details enter successful...");
		driver.navigate().to(
				"D:\\Users\\panbag\\Desktop\\BDD wrkspace\\177510_panbarasan\\src\\test\\java\\html\\EducationalDetails.html");

	}

}
