package com.cg.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class EducationalBookingPage {
	private WebDriver webDriver;
	

	@FindBy(how=How.XPATH,using="/html/body/h4")
	private WebElement heading;
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[1]")
	@CacheLookup
	private WebElement Graduaction;
	@FindBy(how=How.ID,using="txtPercentage")
	@CacheLookup
	private WebElement percentage;
	@FindBy(how=How.NAME,using="passingYear")
	@CacheLookup
	private WebElement passing_year;
	@FindBy(how=How.ID,using="txtProjectName")
	@CacheLookup
	private WebElement project_name;
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[6]")
	@CacheLookup
	private WebElement tech_used ;
	@FindBy(how=How.NAME,using="otherTechnologies")
	@CacheLookup
	private WebElement other_tech;
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[8]")
	@CacheLookup
	private WebElement registerbtn;
	
	public EducationalBookingPage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EducationalBookingPage(WebDriver webDriver) {
		super();
		this.webDriver = webDriver;
}
	
	public String getHeading() {                       
		return this.heading.getText();
	}
	
	public WebElement getGraduaction() {
		return Graduaction;
	}
	public void setGraduaction(String graduaction) {
		Graduaction.sendKeys(graduaction);;
	}
	public WebElement getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);;
	}
	public WebElement getPassing_year() {
		return passing_year;
	}
	public void setPassing_year(String passing_year) {
		this.passing_year.sendKeys(passing_year);;
	}
	public WebElement getProject_name() {
		return project_name;
	}
	public void setProject_name(String project_name) {
		this.project_name.sendKeys(project_name);;
	}
	public WebElement getTech_used() {
		return tech_used;
	}
	public void setTech_used(String tech_used) {
		this.tech_used.sendKeys(tech_used);;
	}
	public WebElement getOther_tech() {
		return other_tech;
	}
	public void setOther_tech(String other_tech) {
		this.other_tech.sendKeys(other_tech);;
	}
	public WebElement getRegisterbtn() {
		return registerbtn;
	}
	public void Registerbtnclick() {
		this.registerbtn.click();;
	}
}