package com.cg.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PersonalDetailPage {
	
	private WebDriver webDriver;
	
	@FindBy(how=How.XPATH,using="/html/body/h4")
	private WebElement heading;
	@FindBy(how = How.ID,using = "txtFirstName")
	@CacheLookup
	private WebElement f_name;
	@FindBy(how = How.ID,using = "txtLastName")
	@CacheLookup
	private WebElement l_name;
	@FindBy(how = How.NAME,using = "Email")
	@CacheLookup
	private WebElement email;
	@FindBy(how = How.NAME,using = "txtPhone")
	@CacheLookup
	private WebElement contact_No;
	@FindBy(how = How.ID,using = "txtAddress1")
	@CacheLookup
	private WebElement addressline_one;
	@FindBy(how = How.NAME,using = "address2")
	@CacheLookup
	private WebElement addressline_two;
	@FindBy(how = How.XPATH,using = "/html/body/form/table/tbody/tr[9]")
	@CacheLookup
	private WebElement city;
	@FindBy(how = How.XPATH,using = "/html/body/form/table/tbody/tr[10]")
	@CacheLookup
	private WebElement state;
	@FindBy(how = How.XPATH,using = "/html/body/form/table/tbody/tr[11]")
	@CacheLookup
	private WebElement nxtbtn;


	
	public PersonalDetailPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PersonalDetailPage(WebDriver webDriver) {
		super();
		this.webDriver = webDriver;
	}
	
	public String getHeading() {                       
		return this.heading.getText();
	}

	public WebElement getF_name() {
		return f_name;
	}

	public void setF_name(String f_name) {
		this.f_name.sendKeys(f_name);;
	}

	public WebElement getL_name() {
		return l_name;
	}

	public void setL_name(String l_name) {
		this.l_name.sendKeys(l_name);;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}

	public WebElement getContact_No() {
		return contact_No;
	}

	public void setContact_No(String contact_No) {
		this.contact_No.sendKeys(contact_No);;
	}

	public WebElement getAddressline_one() {
		return addressline_one;
	}

	public void setAddressline_one(String addressline_one) {
		this.addressline_one.sendKeys(addressline_one);;
	}

	public WebElement getAddressline_two() {
		return addressline_two;
	}

	public void setAddressline_two(String addressline_two) {
		this.addressline_two.sendKeys(addressline_two);;
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);;
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);;
	}

	public void Nxtbtnclick() {
		this.nxtbtn.click();;
	}
	public void setPhoneno(String contact_No) {
		this.contact_No.sendKeys(contact_No);
	}


	
	
	
}
