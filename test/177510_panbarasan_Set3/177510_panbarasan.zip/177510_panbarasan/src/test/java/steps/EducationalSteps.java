package steps;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.pages.EducationalBookingPage;
import com.cg.pages.PersonalDetailPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class EducationalSteps {
	WebDriver driver;
    EducationalBookingPage edupage;
    @Before
	public void start() {
		driver =BrowserFactory.startBrowser("chrome",
				"D:\\Users\\panbag\\Desktop\\BDD wrkspace\\177510_panbarasan\\src\\test\\java\\html\\EducationalDetails.html");

	}
	

//
//@Given("^user is in educational detail page$")
//public void user_is_in_educational_detail_page() throws Throwable {
//	edupage = PageFactory.initElements(driver, EducationalBookingPage.class);
//   
//}
//
//@Then("^verify the tittle educational detail if it is not match$")
//public void verify_the_tittle_educational_detail_if_it_is_not_match() throws Throwable {
//	assertEquals("Educational Details", edupage.getHeading());
//	if (edupage.getHeading().equals("Educational Details")) {
//		System.out.println("tittle is matched");
//	} else {
//		System.out.println("tittle Not Matched");
//		
//	}
// 
//}
//
//@Then("^stop the execution$")
//public void stop_the_execution() throws Throwable {
//	driver.quit();
//   
//}
//
//@Then("^the user leaves without select the  graduation$")
//public void the_user_leaves_without_select_the_graduation() throws Throwable {
//	edupage.setGraduaction("");
//	edupage.setPercentage("70%");
//	edupage.setPassing_year("2018");
//	edupage.setProject_name("Steganography");
//	edupage.setTech_used("java");
//	edupage.setOther_tech("cloud");
//   
//}
//
//@Then("^alert message please select the graduation$")
//public void alert_message_please_select_the_graduation() throws Throwable {
//	try {
//		Alert alt =driver .switchTo().alert();
//		Thread.sleep(1000);
//		String message = alt.getText();
//		assertEquals("Please select graduaction", message);
//		if (message.contentEquals("Please select graduaction")) {
//			System.out.println("The text message on alert box is " + message);
//		} else {
//			System.out.println("the text message on alert is not correct");
//		}
//		alt.accept();
//	} catch (Exception e) {
//		System.out.println("graduaction is Empty");
//	}
//    
//}
//
//@Then("^the user leaves without enter the  percentage$")
//public void the_user_leaves_without_enter_the_percentage() throws Throwable {
//	edupage.setGraduaction("BE");
//	edupage.setPercentage("");
//	edupage.setPassing_year("2018");
//	edupage.setProject_name("Steganography");
//	edupage.setTech_used("java");
//	edupage.setOther_tech("cloud");
// }
//
//@Then("^alert message please enter the  percentage$")
//public void alert_message_please_enter_the_percentage() throws Throwable {
//	try {
//		Alert alt =driver .switchTo().alert();
//		Thread.sleep(1000);
//		String message = alt.getText();
//		assertEquals("Please select percentage", message);
//		if (message.contentEquals("Please select percentage")) {
//			System.out.println("The text message on alert box is " + message);
//		} else {
//			System.out.println("the text message on alert is not correct");
//		}
//		alt.accept();
//	} catch (Exception e) {
//		System.out.println("percentage is Empty");
//	}
//  
//}
//
//@Then("^the user leaves without enter the  year of passing$")
//public void the_user_leaves_without_enter_the_year_of_passing() throws Throwable {
//	edupage.setGraduaction("BE");
//	edupage.setPercentage("80%");
//	edupage.setPassing_year("");
//	edupage.setProject_name("Steganography");
//	edupage.setTech_used("java");
//	edupage.setOther_tech("cloud");
//    
//}
//
//@Then("^alert message please enter the year of passing$")
//public void alert_message_please_enter_the_year_of_passing() throws Throwable {
//	try {
//		Alert alt =driver .switchTo().alert();
//		Thread.sleep(1000);
//		String message = alt.getText();
//		assertEquals("Please fuill passding year", message);
//		if (message.contentEquals("Please fuill passing year")) {
//			System.out.println("The text message on alert box is " + message);
//		} else {
//			System.out.println("the text message on alert is not correct");
//		}
//		alt.accept();
//	} catch (Exception e) {
//		System.out.println("year is Empty");
//	}
//   
//}
//
//@Then("^the user leaves without enter the   projectname$")
//public void the_user_leaves_without_enter_the_projectname() throws Throwable {
//	edupage.setGraduaction("BE");
//	edupage.setPercentage("80%");
//	edupage.setPassing_year("2016");
//	edupage.setProject_name("");
//	edupage.setTech_used("java");
//	edupage.setOther_tech("cloud");
//    
//}
//
//@Then("^alert message please enter the projectname$")
//public void alert_message_please_enter_the_projectname() throws Throwable {
//	try {
//		Alert alt =driver .switchTo().alert();
//		Thread.sleep(1000);
//		String message = alt.getText();
//		assertEquals("Please fill project name", message);
//		if (message.contentEquals("Please fill project name")) {
//			System.out.println("The text message on alert box is " + message);
//		} else {
//			System.out.println("the text message on alert is not correct");
//		}
//		alt.accept();
//	} catch (Exception e) {
//		System.out.println("projectname is Empty");
//	}
//   
//}
//
//@Then("^the user leaves without select the technologies$")
//public void the_user_leaves_without_select_the_technologies() throws Throwable {
//	edupage.setGraduaction("BE");
//	edupage.setPercentage("80%");
//	edupage.setPassing_year("2016");
//	edupage.setProject_name("steagenography");
//	edupage.setTech_used("");
//	edupage.setOther_tech("cloud");
//  
//}
//
//@Then("^alert message please select the technologies used$")
//public void alert_message_please_select_the_technologies_used() throws Throwable {
//	try {
//		Alert alt =driver .switchTo().alert();
//		Thread.sleep(1000);
//		String message = alt.getText();
//		assertEquals("Please  select the technologies", message);
//		if (message.contentEquals("Please  select the technologies")) {
//			System.out.println("The text message on alert box is " + message);
//		} else {
//			System.out.println("the text message on alert is not correct");
//		}
//		alt.accept();
//	} catch (Exception e) {
//		System.out.println("technologies is Empty");
//	}
//   
//}
//
//@Then("^alert message pleasefill other technologies$")
//public void alert_message_pleasefill_other_technologies() throws Throwable {
//	edupage.setGraduaction("BE");
//	edupage.setPercentage("80%");
//	edupage.setPassing_year("2016");
//	edupage.setProject_name("steagenography");
//	edupage.setTech_used("java");
//	edupage.setOther_tech("");
//  
//    
//}
//
//@Then("^the user enter all the field correct$")
//public void the_user_enter_all_the_field_correct() throws Throwable {
//	try {
//		Alert alt =driver .switchTo().alert();
//		Thread.sleep(1000);
//		String message = alt.getText();
//		assertEquals("Please  select the othertechnologies", message);
//		if (message.contentEquals("Please  select the othertechnologies")) {
//			System.out.println("The text message on alert box is " + message);
//		} else {
//			System.out.println("the text message on alert is not correct");
//		}
//		alt.accept();
//	} catch (Exception e) {
//		System.out.println("othertechnologies is Empty");
//	}
//    
//}
//
//@Then("^alert message your registraction successfully done please check your mail$")
//public void alert_message_your_registraction_successfully_done_please_check_your_mail() throws Throwable {
//	System.out.println("your Registraction has successfully done please check your registered email for account activation link");
//   
//}
//


}
