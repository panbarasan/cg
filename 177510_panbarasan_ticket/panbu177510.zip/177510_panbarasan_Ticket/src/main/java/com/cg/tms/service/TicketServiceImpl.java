package com.cg.tms.service;

import java.util.Collection;
import java.util.List;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketServiceImpl implements TicketService {
	TicketDAO tdao=new TicketDAOImpl();

	public boolean raiseNewTicket(TicketBean ticketBean) {
		
		return false;
	}

	public List<TicketCategory> listTicketCategory() {
	
		return null;
	}

}
