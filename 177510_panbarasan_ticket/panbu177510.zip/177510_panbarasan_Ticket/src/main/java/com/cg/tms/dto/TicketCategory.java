package com.cg.tms.dto;

public class TicketCategory {
	private String ticketCategoryId;
	private String categoryname;
	public TicketCategory() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TicketCategory(String ticketCategoryId, String categoryname) {
		super();
		this.ticketCategoryId = ticketCategoryId;
		this.categoryname = categoryname;
	}
	public String getTicketCategoryId() {
		return ticketCategoryId;
	}
	public void setTicketCategoryId(String ticketCategoryId) {
		this.ticketCategoryId = ticketCategoryId;
	}
	public String getCategoryname() {
		return categoryname;
	}
	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}
	@Override
	public String toString() {
		return "TicketCategory [ticketCategoryId=" + ticketCategoryId + ", categoryname=" + categoryname + "]";
	}
	public void setComplaintategoryId(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setCategoryName(String string) {
		// TODO Auto-generated method stub
		
	}
	
	

}
