package com.cg.tms.ui;

import java.util.Random;
import java.util.Scanner;

public class MainU {
public static void main(String[] args) {
	
	
	
	
	System.out.println("welcome to ITIMD Help Desk");
	Scanner scanner=new Scanner(System.in);
	Scanner scanner1=new Scanner(System.in);
	System.out.println("select the category from the list");
	System.out.println("1.software installation");
	System.out.println("2.mailbox creation");
	System.out.println("3.network issuers");
	int num=scanner.nextInt();
	if(num==2)
	{
		System.out.println("enter the related issue");
		System.out.print("enter the priority(1.low medium3.high:2");
		System.out.println("ticket number 2342 loged successfully at 19 march 2017 10:00 am");
		
	}
	
}}