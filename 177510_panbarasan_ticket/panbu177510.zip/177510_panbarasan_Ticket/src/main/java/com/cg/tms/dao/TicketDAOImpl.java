package com.cg.tms.dao;

import java.util.List;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketDAOImpl implements TicketDAO {

	public boolean raiseNewTicket(TicketBean ticketBean) {
		return false;
	}

	public List<TicketCategory> listTicketCategory() {
		return null;
	}

}
