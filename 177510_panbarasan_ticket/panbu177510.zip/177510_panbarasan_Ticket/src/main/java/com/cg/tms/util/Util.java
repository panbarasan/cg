package com.cg.tms.util;

import java.util.HashMap;
import java.util.Map;

public class Util {
	private static Map<String, String> ticketCategory=new HashMap<String, String>();
	//private static Map<Integer, String> ticketLog=new HashMap<Integer, String>();
	public static Map<String, String> getTicketCategoryEntries(){
		ticketCategory.put("tc001", "software installation");
		ticketCategory.put("tc001", "mailbox creation");
		ticketCategory.put("tc003", "mailbox issues");
		
		return ticketCategory;
	//	return ticketLog;
	}

}
