package com.cg.tms.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketDAOImplTest {
	static TicketDAOImpl tdao;
	static TicketBean test;
	 static TicketCategory test1;
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		tdao=new TicketDAOImpl();
		test=new TicketBean();
		test1=new TicketCategory();
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		tdao=null;
		test=null;
		test1=null;
		
	}

	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
	
	}
}
