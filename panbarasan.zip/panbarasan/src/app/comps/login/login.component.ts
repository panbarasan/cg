import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Login } from 'src/app/login';

//component provide the congiguration of metadata
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;
  login: Login = { "name": "", "address": "", "pincode": 0 };
  constructor(private formbuilder: FormBuilder) { }
  success = '"Invalid!!"';

  // ngOnInit used for all the initialization/declaration
  ngOnInit() {
    this.registerForm = this.formbuilder.group({
      name: ['', Validators.required],
      address: ['', Validators.required],
      pincode: ['', Validators.required],
    })

  }

  // convenience way to access the form fields
  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;

    //The form is stop if the condition is invalid
    if (this.registerForm.invalid) {
      return;
    }
    this.success = ('"Valid"')

  }
}
