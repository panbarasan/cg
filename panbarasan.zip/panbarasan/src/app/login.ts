export class Login {
    name:string
    address:string;
    pincode:number;
}
